from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
import google.generativeai as genai
from werkzeug.utils import secure_filename
import os
from PyPDF2 import PdfReader
import serial

app = Flask(__name__)

# Configure Gemini API
def get_gemini_response(prompt: str) -> str:
    """
    Sends a prompt to the Gemini model and retrieves the response.
    """
    genai.configure(api_key="AIzaSyAwJ6rTozBoXQW2K99MZgwU3AzoLrjfxHQ")
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)
    return response.text

# Configure serial port
SERIAL_PORT = "/dev/cu.usbserial-11220"  # Replace with the correct serial port for your system
BAUD_RATE = 9600

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
except Exception as e:
    print(f"Error initializing serial port: {e}")
    ser = None

# Set upload folder
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/process_audio', methods=['POST'])
def process_audio():
    try:
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source)
            audio_data = recognizer.listen(source)

        # Transcribe audio
        text = recognizer.recognize_google(audio_data, language="en-US")

        # Get response from Gemini
        gemini_response = get_gemini_response(text)

        # Send to serial port
        if ser:
            ser.write(f" {text}\nGemini Response: {gemini_response}\n".encode())

        return jsonify({"transcription": text, "gemini_response": gemini_response})

    except sr.UnknownValueError:
        return jsonify({"error": "Google Speech Recognition could not understand the audio."})
    except sr.RequestError as e:
        return jsonify({"error": f"Google Speech Recognition service error: {e}"})
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded."})

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected."})

    try:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(file_path)

        # Extract text from file
        if filename.endswith('.pdf'):
            with open(file_path, "rb") as f:
                reader = PdfReader(f)
                content = " ".join(page.extract_text() for page in reader.pages)
        elif filename.endswith('.txt'):
            with open(file_path, "r") as f:
                content = f.read()
        else:
            return jsonify({"error": "Unsupported file format. Only .txt and .pdf are allowed."})

        # Get response from Gemini
        gemini_response = get_gemini_response(content)

        # Send to serial port
        if ser:
            ser.write(f"{content}\nGemini Response: {gemini_response}\n".encode())

        return jsonify({"content": content, "gemini_response": gemini_response})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    try:
        app.run(debug=True)
    finally:
        if ser:
            ser.close()
