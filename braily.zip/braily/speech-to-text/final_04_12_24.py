import os
import speech_recognition as sr
import google.generativeai as genai
import serial

def transcribe_audio(audio_data, language="en-US") -> str:
    """
    Transcribes audio data to text using Google's speech recognition API.
    """
    recognizer = sr.Recognizer()
    return recognizer.recognize_google(audio_data, language=language)

def speech_to_text_from_mic(language="en-US") -> str:
    """
    Captures audio from the microphone, transcribes it, and returns the transcription as text.
    """
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Adjusting for ambient noise. Please wait...")
        recognizer.adjust_for_ambient_noise(source)
        print("Please speak now:")
        audio_data = recognizer.listen(source)
        try:
            print("Transcribing audio...")
            text = transcribe_audio(audio_data, language=language)
            print("Transcription:")
            print(text)
            return text
        except sr.UnknownValueError:
            print("Google Speech Recognition could not understand the audio.")
            return ""
        except sr.RequestError as e:
            print(f"Could not request results from Google Speech Recognition service; {e}")
            return ""

def get_gemini_response(prompt: str) -> str:
    """
    Sends a prompt to the Gemini model and retrieves the response.
    """
    genai.configure(api_key="AIzaSyAwJ6rTozBoXQW2K99MZgwU3AzoLrjfxHQ")
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)
    return response.text

if __name__ == '__main__':
    print("Waiting for 'start' command from the serial monitor...")
    try:
        # Set up serial communication
        serial_port = serial.Serial(port='COM3', baudrate=9600, timeout=1)  # Replace 'COM3' with the correct port for your system
        while True:
            # Read data from serial port
            if serial_port.in_waiting > 0:
                command = serial_port.readline().decode('utf-8').strip()
                print(f"Received command: {command}")
                
                if command.lower() == "start":
                    print("Starting speech-to-text and Gemini integration...")
                    
                    # Step 1: Get text input from microphone
                    transcribed_text = speech_to_text_from_mic()
                    
                    if transcribed_text:
                        # Step 2: Send transcribed text to Gemini and get response
                        print("\nSending transcribed text to Gemini API...")
                        gemini_response = get_gemini_response(transcribed_text)
                        print("\nGemini Response:")
                        print(gemini_response)
                    else:
                        print("No valid transcription available to send to Gemini.")
    
    except Exception as e:
        print("Error:", e)
