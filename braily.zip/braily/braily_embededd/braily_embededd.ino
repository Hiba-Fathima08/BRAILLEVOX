/* Sweep
 by BARRAGAN <http://barraganstudio.com>
 This example code is in the public domain.

 modified 8 Nov 2013
 by Scott Fitzgerald
 https://www.arduino.cc/en/Tutorial/LibraryExamples/Sweep
*/

#include <Servo.h>

Servo servo1;  //           
Servo servo2;
Servo servo3;
Servo servo4;
Servo servo5;
Servo servo6;

#define one 2
#define two 3
#define three 4
#define four 5
#define five 6
#define six 7
#define speak 8

// twelve Servo objects can be created on most boards

String storedData = "";

void setup() {
servo1.attach(one);
servo2.attach(two);
servo3.attach(three);
servo4.attach(four);
servo5.attach(five);
servo6.attach(six);

pinMode(speak,INPUT_PULLUP);

  servo1.write(40);

  delay(50);
  servo2.write(40);


  delay(50);
  servo3.write(40);

  delay(50);
  servo4.write(40);

  delay(50);
  servo5.write(0);

  delay(50);
  servo6.write(0);

  delay(50);
   Serial.begin(9600);

}

void loop() {
  // Check if data is available on the Serial port
 if (digitalRead(speak) == LOW) {
  Serial.println("speak");
  // Serial.println(" hai ");
  delay(2000);
}

  if (Serial.available() > 0) {
    // Read the incoming data
    storedData = Serial.readStringUntil('\n');

    // Print the received data to the Serial monitor
    Serial.println("Received:");
    Serial.println(storedData);

    // Process and display the stored data word by word
    int startIndex = 0;
    int endIndex = storedData.indexOf(' ');

    while (endIndex != -1) {
      String word = storedData.substring(startIndex, endIndex);
      showWordByLetters(word);
      startIndex = endIndex + 1;
      endIndex = storedData.indexOf(' ', startIndex);
    }

    // Show the last word
    String lastWord = storedData.substring(startIndex);
    showWordByLetters(lastWord);
  }
}

void showWordByLetters(String word) {
  for (int i = 0; i < word.length(); i++) {
    char currentChar = word[i];
    Serial.println(currentChar);  // Print the character to the serial monitor

    switch (currentChar) {

      case '0':
        Zero();  // Function for 'a' or 'A'
        break;
      case 'a':
      case 'A':
        A();  // Function for 'a' or 'A'
        break;
      case 'b':
      case 'B':
        B();  // Function for 'b' or 'B'
        break;
      case 'c':
      case 'C':
        C();  // Function for 'c' or 'C'
        break;
      case 'd':
      case 'D':
        D();  // Function for 'd' or 'D'
        break;
      case 'e':
      case 'E':
        E();  // Function for 'e' or 'E'
        break;
      case 'f':
      case 'F':
        F_1();  // Function for 'f' or 'F'
        break;
      case 'g':
      case 'G':
        G();  // Function for 'g' or 'G'
        break;
      case 'h':
      case 'H':
        H();  // Function for 'h' or 'H'
        break;
      case 'i':
      case 'I':
        I();  // Function for 'i' or 'I'
        break;
      case 'j':
      case 'J':
        J();  // Function for 'j' or 'J'
        break;
      case 'k':
      case 'K':
        K();  // Function for 'k' or 'K'
        break;
      case 'l':
      case 'L':
        L();  // Function for 'l' or 'L'
        break;
      case 'm':
      case 'M':
        M();  // Function for 'm' or 'M'
        break;
      case 'n':
      case 'N':
        N();  // Function for 'n' or 'N'
        break;
      case 'o':
      case 'O':
        O();  // Function for 'o' or 'O'
        break;
      case 'p':
      case 'P':
        P();  // Function for 'p' or 'P'
        break;
      case 'q':
      case 'Q':
        Q();  // Function for 'q' or 'Q'
        break;
      case 'r':
      case 'R':
        R();  // Function for 'r' or 'R'
        break;
      case 's':
      case 'S':
        S();  // Function for 's' or 'S'
        break;
      case 't':
      case 'T':
        T();  // Function for 't' or 'T'
        break;
      case 'u':
      case 'U':
        U();  // Function for 'u' or 'U'
        break;
      case 'v':
      case 'V':
        V();  // Function for 'v' or 'V'
        break;
      case 'w':
      case 'W':
        W();  // Function for 'w' or 'W'
        break;
      case 'x':
      case 'X':
        X();  // Function for 'x' or 'X'
        break;
      case 'y':
      case 'Y':
        Y();  // Function for 'y' or 'Y'
        break;
      case 'z':
      case 'Z':
        Z();  // Function for 'z' or 'Z'
        break;
      default:
        // Handle non-alphabet characters if necessary
        break;
    }
    
    delay(2000); // 2-second delay between each letter
  }
  zero();

}



void Zero(){
   servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(0);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("0");
}

void A(){
   servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(40);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("a");
}

void B(){
   servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);

  servo5.write(40);
delay(50);

  servo6.write(40);
delay(50);
Serial.println("b");

}

void C(){
   servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);

Serial.println("c");

}

void D(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("d");
}


void E(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(40);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("e");
}

void F_1(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);

Serial.println("f");
}

void G(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("g");
}

void H(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("h");

}

void I(){
  servo1.write(40);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("i");
}

void J(){
  servo1.write(40);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("j");
}

void K(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("k");
}

void L(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("l");
}

void M(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(0);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("m");
}

void N(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(0);
delay(50);

  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("n");
}

void O(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("o");
}

void P(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);


delay(50);
Serial.println("p");
}


void Q(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("q");
}

void R(){
 servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("r");
}

void S(){
  servo1.write(40);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("s");
}

void T(){
    servo1.write(40);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(40);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("t");
}

void U(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(0);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("u");
}

void V(){
  servo1.write(0);
delay(50);
  servo2.write(40);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(0);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("v");
}

void W(){
  servo1.write(40);
delay(50);
  servo2.write(40);
delay(50);

  servo3.write(40);
delay(50);

  servo4.write(0);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("w");
}

void X(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(0);
delay(50);

  servo4.write(0);
delay(50);
  servo5.write(40);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("x");
}

void Y(){
   servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);

  servo3.write(0);
delay(50);

  servo4.write(0);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(0);
delay(50);
Serial.println("y");
}

void Z(){
  servo1.write(0);
delay(50);
  servo2.write(0);
delay(50);
  servo3.write(0);
delay(50);
  servo4.write(0);
delay(50);
  servo5.write(0);
delay(50);
  servo6.write(40);
delay(50);
Serial.println("z");
}

void zero(){
  servo1.write(40);

  delay(50);
  servo2.write(0);


  delay(50);
  servo3.write(40);

  delay(50);
  servo4.write(40);

  delay(50);
  servo5.write(40);

  delay(50);
  servo6.write(40);

}
